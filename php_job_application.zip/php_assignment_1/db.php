<?php
// Update these values to match your local MySQL setup.
$host = 'localhost';
$dbname = 'job_application_db';
$dbuser = 'root';
$dbpass = ''; // Enter your MySQL password if you have one.

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $dbuser,
        $dbpass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    exit('Database connection failed. Check db.php settings and import database.sql.');
}
