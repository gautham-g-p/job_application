<?php
require_once __DIR__ . '/db.php';

try {
    // Fetch applicant details. Passwords are deliberately not selected.
    $stmt = $pdo->query(
        'SELECT name, email, mobile, username
         FROM applicants
         ORDER BY id DESC'
    );
    $applicants = $stmt->fetchAll();
} catch (PDOException $e) {
    http_response_code(500);
    exit('Unable to retrieve applicant records. Please check the database setup.');
}

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Applicant Records</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <main class="container wide">
        <h1>Applicant Records</h1>
        <p class="intro">Details of applicants stored in the database.</p>

        <p class="record-count">
            Total applicants: <strong><?= count($applicants) ?></strong>
        </p>

        <?php if (count($applicants) > 0): ?>
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Mobile Number</th>
                            <th>Username</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($applicants as $applicant): ?>
                            <tr>
                                <td><?= e($applicant['name']) ?></td>
                                <td><?= e($applicant['email']) ?></td>
                                <td><?= e($applicant['mobile']) ?></td>
                                <td><?= e($applicant['username']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p class="empty-message">No applicant records found. Submit an application first.</p>
        <?php endif; ?>

        <p class="back-link"><a href="index.php">Back to application form</a></p>
    </main>
</body>
</html>
