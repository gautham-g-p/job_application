<?php
require_once __DIR__ . '/db.php';

$errors = [];
$success = '';
$name = $email = $mobile = $username = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $mobile = trim($_POST['mobile'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    // Name: letters, spaces, apostrophes and hyphens only.
    if ($name === '' || !preg_match("/^[\p{L}][\p{L}\s'-]{1,49}$/u", $name)) {
        $errors[] = 'Enter a valid name (2–50 characters; letters, spaces, apostrophes and hyphens only).';
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Enter a valid email address.';
    }

    // This assignment uses the common Indian 10-digit mobile number format.
    if (!preg_match('/^[6-9][0-9]{9}$/', $mobile)) {
        $errors[] = 'Enter a valid 10-digit Indian mobile number starting with 6, 7, 8 or 9.';
    }

    if (!preg_match('/^[A-Za-z0-9_]{4,20}$/', $username)) {
        $errors[] = 'Username must be 4–20 characters and contain only letters, numbers or underscores.';
    }

    if (strlen($password) < 8 ||
        !preg_match('/[0-9]/', $password) ||
        !preg_match('/[A-Z]/', $password) ||
        !preg_match('/[a-z]/', $password)) {
        $errors[] = 'Password must be at least 8 characters and include a number, an uppercase letter and a lowercase letter.';
    }

    if (!$errors) {
        try {
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare(
                'INSERT INTO applicants (name, email, mobile, username, password)
                 VALUES (:name, :email, :mobile, :username, :password)'
            );
            $stmt->execute([
                ':name' => $name,
                ':email' => $email,
                ':mobile' => $mobile,
                ':username' => $username,
                ':password' => $passwordHash
            ]);

            $success = 'Your application has been submitted successfully.';
            $name = $email = $mobile = $username = '';
        } catch (PDOException $e) {
            if ($e->getCode() === '23000') {
                $errors[] = 'That email address or username is already registered. Please use another one.';
            } else {
                $errors[] = 'Unable to save your application right now. Check the database settings and try again.';
            }
        }
    }
}
function e($value) {
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Job Application Form</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <main class="container">
        <h1>Job Application Form</h1>
        <p class="intro">Please enter your details to submit your application.</p>

        <?php if ($success): ?>
            <div class="message success" role="status"><?= e($success) ?></div>
        <?php endif; ?>

        <?php if ($errors): ?>
            <div class="message error" role="alert">
                <strong>Please correct the following:</strong>
                <ul>
                    <?php foreach ($errors as $error): ?>
                        <li><?= e($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="post" action="index.php">
            <label for="name">Name</label>
            <input type="text" id="name" name="name" value="<?= e($name) ?>" required>

            <label for="email">Email</label>
            <input type="email" id="email" name="email" value="<?= e($email) ?>" required>

            <label for="mobile">Mobile number</label>
            <input type="tel" id="mobile" name="mobile" value="<?= e($mobile) ?>"
                   placeholder="10-digit mobile number" maxlength="10" required>

            <label for="username">Username</label>
            <input type="text" id="username" name="username" value="<?= e($username) ?>"
                   minlength="4" maxlength="20" required>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" minlength="8" required>

            <p class="hint">Password: minimum 8 characters, with at least one uppercase letter, one lowercase letter and one number.</p>

            <button type="submit">Submit Application</button>
        </form>
    </main>
</body>
</html>
